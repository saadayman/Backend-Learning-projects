const express = require("express");
const { Collection } = require("mongodb");
const app = express();
const path = require("path");
const PORT = process.env.PORT || 5000;
const Joi = require("joi");

const schema = Joi.object({
  todo: Joi.string().required(),
});
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const db = require("./db");
const collection = "todo";

app.use(express.static(path.join(__dirname, "public")));
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "todo.html"));
});
app.get("/getTodos", (req, res) => {
  db.getDB()
    .collection(collection)
    .find()
    .toArray((err, documents) => {
      if (err) console.log(err);
      else {
        console.log(documents);
        res.json(documents);
      }
    });
});
//to update the data
app.put("/:id", (req, res) => {
  const todoID = req.params.id;
  const userInput = req.body;
  db.getDB()
    .collection(collection)
    .findOneAndUpdate(
      { _id: db.getPrimaryKey(todoID) },
      {
        $set: {
          todo: userInput.todo, //to update the existed instead of overwriting it
        },
      },
      { returnOriginal: false },
      (err, result) => {
        if (err) console.log(err);
        else {
          res.json(result);
        }
      }
    );
});
app.post("/", (req, res) => {
  const newTodo = req.body;
  const validation = schema.validate(newTodo);
  console.log(validation);
  if (validation.error) {
    res.status(400).json({ error: validation.error.message });
  } else {
    db.getDB()
      .collection(collection)
      .insertOne(newTodo, (err, result) => {
        if (err) {
          console.log(err.message);
        } else {
          res.json({
            result: result,
            document: [
              {
                todo: newTodo.todo,
                _id: result.insertedId,
              },
            ],
          });
        }
      });
  }
});
app.delete("/:id", (req, res) => {
  const todoID = req.params.id;
  console.log(todoID);
  db.getDB()
    .collection(collection)
    .findOneAndDelete({ _id: db.getPrimaryKey(todoID) }, (err, result) => {
      if (err) console.log(err);
      else {
        res.json({ msg: "Element was removed", result });
      }
    });
});

db.connect((err) => {
  if (err) {
    console.log("unable to connect to datebase");
    process.exit(1);
  } else {
    app.listen(PORT, () => {
      console.log(`Connected to database on port ${PORT}`);
    });
  }
});
