// const todosContainer = document.querySelector('#todos-container')

// const url= 'http://localhost:5000/getTodos'
// //fetch the data from our api
// fetchData()
// async function fetchData(){
//     const res = await fetch(url)
//     const data = await res.json()
//    CreateElements(data)
// }

// //to create li for each element
// function CreateElements(data){
//     data.forEach((element,idx) => {
//         const li = document.createElement('li')
//         li.className="list-group-item d-flex justify-content-between align-items-center w-100"
//         li.innerHTML= `  <p class="p-0 m-0">${data[idx].todo}</p>
//         <div>
//          <button data-id=${data[idx]._id} class="btn btn-primary">EDIT</button>  <button data-id = ${data[idx]._id} class="btn btn-danger">X</button>

//         </div>`
//         todosContainer.append(li)
//     });

// }
$(document).ready(() => {
  const ul = $("#todos-container");
  const form = $("#form");
  const userInput = $("#user-input");

  const deleteTodo = (todo, listItemID, deleteID) => {
    let deleteBtn = $(`#${deleteID}`);
    deleteBtn.click(() => {
      fetch(`/${todo._id}`, {
        method: "delete",
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          if (data.result.ok == 1) {
            $(`#${listItemID}`).remove();
          }
        });
    });
  };
  const editTodo = (todo, todoID, editID) => {
    let editBtn = $(`#${editID}`);
    editBtn.click(() => {
      fetch(`/${todo._id}`, {
        method: "put",
        headers: {
          "Content-Type": "application/json; charset=utf-8",
        },
        body: JSON.stringify({ todo: userInput.val() }),
      })
        .then((res) => {
          return res.json();
        })
        .then((data) => {
          let todoIndex = $(`#${todoID}`);

          if (data.ok == 1 && data.lastErrorObject.n == 1) {
            todoIndex.html(`${data.value.todo}`);
            console.log(data.value, "1");
          }
          restTdosInput();
        });
    });
  };
  const restTdosInput = () => {
    userInput.val("");
  };
  const buildIDS = (todo) => {
    return {
      editID: "edit_" + todo._id,
      delete: "delete_" + todo._id,
      listItemID: "listItem_" + todo._id,
      todoID: "todo_" + todo._id,
    };
  };
  const buildTemplate = (todo, ids) => {
    return `<li class="list-group-item" id="${ids.listItemID}">
        <div class="row">
        <div class="col-md-4" id="${ids.todoID}">${todo.todo}</div>
        <div class="col-md-4"></div>
        <div class="col-md-4 text-right">
            <button type="button" class="btn btn-secondary" id="${ids.editID}">Edit</button>
            <button type="button" class="btn btn-danger" id="${ids.delete}">Delete</button>
        </div>
        </div>
      </li>`;
  };
  const displayTodos = (data) => {
    data.forEach((todo) => {
      let ids = buildIDS(todo);
      ul.append(buildTemplate(todo, ids));
      editTodo(todo, ids.todoID, ids.editID);
      deleteTodo(todo, ids.listItemID, ids.delete);
    });
  };
  const getTodos = () => {
    fetch("/getTodos", { method: "get" })
      .then((res) => res.json())
      .then((data) => {
        displayTodos(data);
      });
  };
  form.submit((e) => {
    e.preventDefault();
    fetch("/", {
      method: "post",
      body: JSON.stringify({ todo: userInput.val() }),
      headers: { "Content-Type": "application/json; charset=utf-8" },
    })
      .then((res) => {
        return res.json();
      })
      .then((data) => {
        if (data.result.acknowledged == true) {
          let ids = buildIDS(data.document[0]);
          ul.append(buildTemplate(data.document[0], ids));
          editTodo(data.document[0], ids.todoID, ids.editID);
          deleteTodo(data.document[0], ids.listItemID, ids.delete);
          restTdosInput();
        }
      });
  });
  getTodos();
});
