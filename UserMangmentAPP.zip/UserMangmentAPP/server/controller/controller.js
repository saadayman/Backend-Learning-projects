let Userdb = require("../model/model");
// create and save new user
exports.create = (req, res) => {
  //validate request
  if (!req.body) {
   return res.status(400).send({ msg: "Content can not be empty" });
    
  }
  //new user
  const user = new Userdb({
    name: req.body.name,
    email: req.body.email,
    gender: req.body.gender,
    status: req.body.status,
  });
  //save user in the db
  user
    .save(user)
    .then((data) => {
      res.redirect("/");
      console.log(data)
    })
    .catch((err) => {
      res
        .status(500)
        .send({ msg: err.message || "Some unknown error occured" });
    });
};

//retrieve and return all users / retrive and return a single user
// localhost:3000/api/user?id=0000
exports.find = (req, res) => {
  if (req.query.id) {
    Userdb.findById(req.query.id)
      .then((user) => {
        if (!user) {
          res.status(404).send("user was not found");
        } else {
          res.send(user);
        }
      })
      .catch((err) => res.status(500).send("user cant be fetched"));
  } else {
    Userdb.find()
      .then((user) => {
        res.send(user);
      })
      .catch((err) => {
        res
          .status(500)
          .send({ msg: err.message || "Error ocurred while retriving info" });
      });
  }
};

//upadte a new idetified user by user id
exports.update = (req, res) => {
  const userId = req.params.id;
  if (!req.body) {
    return res.status(400).send({ msg: "body can not be empty" });
  }
  Userdb.findByIdAndUpdate(userId, req.body, { useFindAndModify: false }) //(id , updated Data )
    .then((data) => {
      if (!data) {
        return res.status(404).send({ msg: "data was not found" });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).sedn({ msg: "ERROR UPDATE USER INFO" });
    });
};
//Delete a user with specific user id
exports.remove = (req, res) => {
  const userId = req.params.id;
  Userdb.findByIdAndDelete(userId, { useFindAndModify: false })
    .then((data) => {
      if (!data) {
        res.status(404).send({
          msg: `Cannot Delete With id ${userId} maybe it is invalid id `,
        });
      } else {
        res.send({ msg: "user was removed", data });
      }
    })
    .catch((err) => {
      res.status(500).send({ msg: "Server Error" });
    });
};
