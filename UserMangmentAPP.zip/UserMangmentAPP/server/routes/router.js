const express = require("express");
const { homeRoutes, addUser, updateUser } = require("../services/render");
const { create, find, update, remove } = require("../controller/controller");
const router = express.Router();
/**
 * @description Root Route
 * @method GET/
 */
router.get("/", homeRoutes);
/**
 * @description ADD USER ROUTE
 * @method GET/add-user
 */
router.get("/add-user", addUser);
/**
 * @description UPDATE USER ROUTE
 * @method GET/update-user
 */
router.get("/update-user", updateUser);
//API
router.post("/api/users", create);
router.put("/api/users/:id", update);
router.delete("/api/users/:id", remove);
router.get("/api/users", find);

module.exports = router;
