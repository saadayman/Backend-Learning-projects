$("#add_user").submit((e) => {
  alert("Data Inserted Succuessfully");
});
$("#update_user").submit(function (e) {
  e.preventDefault();
  let unindexed_array = $(this).serializeArray(); //this will return all the submitted data the array
  let data = {};
  console.log(unindexed_array);
  $.map(unindexed_array, (n, i) => {
    data[n["name"]] = n["value"];
  });
  let request = {
    url: `http://localhost:3000/api/users/${data.id}`,
    method: "PUT",
    data: data,
  };
  $.ajax(request).done((res) => {
    alert("Data updated Successfuly");
  });
  console.log(request);
});
if(window.location.pathname=="/"){
  $ondelete = $('.table tbody td a.delete')
  $ondelete.click(function(){
    let id = $(this).attr("data-id")
    let request = {
      url:`http://localhost:3000/api/users/${id}`,
      method:"DELETE",
    }
    $.ajax(request).done((res)=>{
     location.reload()
    })
  })

}
